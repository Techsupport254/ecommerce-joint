import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <div>Footer</div>
  )
}

export default Footer